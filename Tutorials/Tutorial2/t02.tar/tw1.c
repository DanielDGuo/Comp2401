// tw1.cpp : correct the errors/warning in the file.
//

#include "stdio.h"


int main(int argc, char* argv[])
{
 int x=12;
 
 printf("25*25 =%d\n',25*25);

 return 0;
}


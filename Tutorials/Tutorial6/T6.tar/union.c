
#include <stdio.h>
#include <stdlib.h>


/***************************************************************************/

// STRUCTURES
// strucure house

// union anotherHouse




/***************************************************************************/


int main(int argc, char *argv[])
{

	//struct house x;
	//union anotherHouse y;

	


}

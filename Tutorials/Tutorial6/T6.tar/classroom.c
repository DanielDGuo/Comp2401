#include <stdio.h>
#include <stdlib.h>

#include "classroom.h"


/*******************************************************/


// populate the classroom with fields

int initClassroom(Classroom *p, int numSeats, int numProjectors, int numBlackboards, int accessible)

{





    return(0);

}



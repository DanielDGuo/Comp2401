/* file is sum.h */

int sum(int firstNum, int lastNum); 



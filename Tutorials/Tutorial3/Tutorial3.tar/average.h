/* file is average.h */

int average(int x, int y, float *average); 



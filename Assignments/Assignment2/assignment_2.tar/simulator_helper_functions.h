
//FUNCTION PROTOTYPES
int computeParityBitShort(short s);
int computeParityBitInt(int i);
float computeFloatValue(int i);

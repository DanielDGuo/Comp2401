// files is arrays.c
/* The program in this file accepts grades and computes the aveage GPA.
it then removes low grades and computes that average GPA
 
 */

#include "stdio.h"
#include "stdlib.h"
#include "math.h"



/*************************************************************************/

/* DEFINE */
#define ARR_SIZE  20


/**********************************************************************/

/* PROTOTYPES */

int populateArray(int numbers[], int maxArrSize, int* arrSize);
int removeValues(int numbers[], int minValue, int* arrSize);
int isPalindrome(int numbers[], int arrSize);
int printArray(int numbers[], int arrSize);
float computeAvgGPA(int arr[], int arrSize);
int computeStdDev(int arr[], int arrSize, float *stdDev);


/**********************************************************************/




int main(int argc, char* argv[])
{
    
    int gpa[ARR_SIZE];
    int arrSize;
    int rc;
    float avgGpa = 0; 
    float stdDev = 0; 


    // populate the array with numbers
    populateArray(gpa, ARR_SIZE, &arrSize);
    printf("The courses grades are:\n");
    printArray(gpa, arrSize);

    // compute the average gpa
    avgGpa = computeAvgGPA(gpa, arrSize);
    
    // compute the standard deviation
    computeStdDev(gpa, arrSize, &stdDev);
    
    // print the number of courses and the average gpa
    printf("The number of courses = %d average GPA = %5.2f  standard deviation = %5.2f\n", arrSize ,avgGpa, stdDev);


    printf("Removing all gpa elements smaller than 7 \n");
    removeValues(gpa, 7, &arrSize);
    printf("The grades with grades >= 7 are:\n");
    printArray(gpa, arrSize);

    // compute the average gpa
    avgGpa = computeAvgGPA(gpa, arrSize);
    
    stdDev = 0;
    // compute the standard deviation
    computeStdDev(gpa, arrSize, &stdDev);
    
    // print the number of courses and the average gpa
    printf("The number of courses = %d average GPA = %5.2f  standard deviation = %5.2f\n", arrSize ,avgGpa, stdDev);


  
  
}


/************************************************************************/

/* Purpose: compute the average gpa of the array

*/

float computeAvgGPA(int arr[], int arrSize)
{

    float avg = 0;
    // add code


    return(avg);

}




/************************************************************************/
/*
numbers - the array of numbers
maxArrSize - the numbers of elements in the array

output :
    numbers - the modified array
    arrSize - the number of elements in the array after the array was populated

Assumptions:
the user is a friendly user - there is no need to check input or clear the buffer
*/
int populateArray(int numbers[], int maxArrSize, int *arrSize)
{

    // add code

    return(0);
}




/************************************************************************/

/*
Purpose: remove all number that are smaller than the given min value.
For example if minValue is 5 then all number in the array that are smaller than 5 are to be removed.

input:
numbers - the array of numbers
minValue - the value
arrSize - the numbers of elements in the array

output:
numbers - the modified array
arrSize - the number of elements in the array after the values were removed

return
0 

*/


int removeValues(int numbers[], int minValue, int* arrSize)
{

    // add code
 
    return(0);
}




/************************************************************************/

/*
Purpose: prints the array


input:
numbers - the array of numbers
arrSize - the numbers of elements in the array


return
0 
*/


int printArray(int numbers[], int arrSize)
{
    int i;


    return(0);

}



/************************************************************************/

/*
Purpose: computes the standard deviation of the grades


input:
arr - the array of integers
arrSize - the numbers of elements in the array

output:
stdDev - the standard deviation of the grades
return
0 
*/


int computeStdDev(int arr[], int arrSize, float *stdDev)
{
 
    //add code

    return(0);

}





